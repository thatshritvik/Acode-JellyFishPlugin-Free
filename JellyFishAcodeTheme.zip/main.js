const plugin = {
  id: "acode.theme.jellyfish",
};

class JellyfishThemePlugin {
  init() {
    // Register the app (UI) theme.
    const themes = acode.require("themes");
    const ThemeBuilder = acode.require("themeBuilder");

    const appTheme = new ThemeBuilder("Jellyfish", "dark");
    appTheme.primaryColor = "#00002c";
    appTheme.popupBackgroundColor = "#171520";
    appTheme.darkenedPrimaryColor = "#00002c";
    appTheme.primaryTextColor = "#ffffff";
    appTheme.secondaryColor = "#010033";
    appTheme.secondaryTextColor = "#ffffff";
    appTheme.activeColor = "#ff0088";
    appTheme.activeIconColor = "#00ffff";
    appTheme.linkTextColor = "#00d9ff";
    appTheme.errorTextColor = "#ff5370";
    appTheme.scrollbarColor = "#00d9ff";
    appTheme.borderColor = "#00d9ff";
    appTheme.popupBorderColor = "#00d9ff";
    appTheme.borderRadius = "4px";
    appTheme.popupBorderRadius = "4px";
    appTheme.popupIconColor = "#00d9ff";
    appTheme.popupTextColor = "#ffffff";
    appTheme.popupActiveColor = "#f9ff24";
    appTheme.boxShadowColor = "#00000033";
    appTheme.buttonActiveColor = "#61afef";
    appTheme.buttonBackgroundColor = "#ff0055";
    appTheme.buttonTextColor = "#ffffff";
    themes.add(appTheme);

    // Register the editor theme using Acode's current CodeMirror API.
    const editorThemes = acode.require("editorThemes");
    const { cm, createTheme, createHighlightStyle } = editorThemes;
    const t = cm.tags;

    const highlight = createHighlightStyle([
      { tag: t.keyword, color: "#ff0062" },
      { tag: [t.string, t.special(t.string)], color: "#eeff00" },
      { tag: [t.number, t.bool, t.null], color: "#ff0062" },
      { tag: t.comment, color: "#838383", fontStyle: "italic" },
      { tag: [t.function(t.variableName), t.propertyName], color: "#00ffff" },
      { tag: [t.typeName, t.className], color: "#fd0076" },
      { tag: t.variableName, color: "#ffcb6b" },
      { tag: [t.operator, t.punctuation], color: "#ffffff" },
      { tag: [t.tagName, t.attributeName], color: "#ff006a" },
      { tag: t.attributeValue, color: "#eeff00" },
      { tag: t.invalid, color: "#ff5370" },
    ]);

    editorThemes.register({
      id: "jellyfish",
      caption: "Jellyfish",
      dark: true,
      getExtension: () => createTheme({
        dark: true,
        styles: {
          "&": { color: "#ffffff", backgroundColor: "#00002c" },
          ".cm-content": { caretColor: "#00f7ff" },
          ".cm-cursor, .cm-dropCursor": { borderLeftColor: "#00f7ff" },
          "&.cm-focused .cm-selectionBackground, .cm-selectionBackground, .cm-content ::selection": {
            backgroundColor: "#ff00885d",
          },
          ".cm-gutters": {
            backgroundColor: "#171520",
            color: "#868686",
            border: "none",
          },
          ".cm-activeLine": { backgroundColor: "#171520" },
          ".cm-activeLineGutter": { backgroundColor: "#171520" },
          ".cm-lineNumbers .cm-gutterElement": { color: "#868686" },
          ".cm-matchingBracket": {
            color: "#f9ff24",
            outline: "1px solid #00d9ff",
          },
        },
        highlightStyle: highlight,
      }),
    });
  }

  destroy() {
    try {
      acode.require("editorThemes").unregister("jellyfish");
    } catch (_) {}
  }
}

const jellyfish = new JellyfishThemePlugin();
acode.setPluginInit(plugin.id, () => jellyfish.init());
acode.setPluginUnmount(plugin.id, () => jellyfish.destroy());
